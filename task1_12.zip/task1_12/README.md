# 任务十二：学习CSS 3的新特性
## 任务描述
- 实现 [示例图（点击查看）](http://7xrp04.com1.z0.glb.clouddn.com/task_1_12_1.jpg) 中的几个例子
- 实现单双行列不同颜色，且前三行特殊表示的表格
- 实现正常状态和focus状态宽度不一致的input文本输入框，且鼠标焦点进入输入框时，宽度的变化以动画呈现
- 不使用JavaScript，实现一个Banner图轮流播放的效果，且点击右下角的1，2，3可以切换到对应Banner图片

## 实现
首先把[地址](http://ifetask.alkalixin.cn/task_12/)放出来

前两个栗子实现比较简单，在做最后一个css轮播的时候遇到点麻烦。

本来想把id直接写在对应的li上，无奈好像没有`父级选择器`这种东西-。-

所以只能通过增加多余标签来实现，不是很优雅，大神们如果有更好的方法，不吝赐教

---
感谢@[欧阳湘粤](http://ife.baidu.com/user/profile?userId=1110)给出意见，已经去掉outline。不过user-select那个没懂-。-